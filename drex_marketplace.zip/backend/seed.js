// Simple seed script to populate services for demo
(async function(){
  const dbModule = require('./db');
  require('dotenv').config();
  await dbModule.initDb();
  const db = module.exports._db;
  // insert demo services
  const services = [
    ['Creative Logo', 'Graphic Design', 10, 1, '/static/assets/logo1.png', 'Professional logo, 2 revisions', 1],
    ['Modern Website', 'Web Development', 25, 3, '/static/assets/site1.png', 'Responsive website with 3 pages', 1],
    ['YouTube Thumbnail', 'Graphic Design', 4, 0.5, '/static/assets/thumb1.png', 'Eye-catching thumbnail', 1],
    ['Discord Bot Setup', 'Bots', 15, 2, '/static/assets/bot1.png', 'Custom discord bot setup and deploy', 0],
  ];
  for (const s of services){
    await db.run('INSERT INTO services (title, category, price, delivery_days, image, description, featured) VALUES (?, ?, ?, ?, ?, ?, ?)', ...s);
  }
  console.log('Seed finished');
  process.exit(0);
})();
