// Simple SQLite wrapper for demo
const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const path = require('path');
const DB_PATH = process.env.DATABASE_PATH || path.join(__dirname, '..', 'db', 'drex.sqlite');

async function initDb(){
  const db = await open({ filename: DB_PATH, driver: sqlite3.Database });
  // create tables if not exist (simple schema)
  await db.exec(`
    CREATE TABLE IF NOT EXISTS services (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT,
      category TEXT,
      price REAL,
      delivery_days INTEGER,
      image TEXT,
      description TEXT,
      featured INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      service_id INTEGER,
      buyer_name TEXT,
      buyer_email TEXT,
      payment_method TEXT,
      tip REAL DEFAULT 0,
      details TEXT,
      status TEXT DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);
  // attach to module
  module.exports._db = db;
}

async function getAllServices(){
  const db = module.exports._db;
  return db.all('SELECT * FROM services ORDER BY featured DESC, id DESC LIMIT 100');
}

async function getServiceById(id){
  const db = module.exports._db;
  return db.get('SELECT * FROM services WHERE id = ?', id);
}

async function createOrder({ serviceId, buyerName, buyerEmail, paymentMethod, details, tip }){
  const db = module.exports._db;
  const result = await db.run('INSERT INTO orders (service_id, buyer_name, buyer_email, payment_method, details, tip) VALUES (?, ?, ?, ?, ?, ?)', serviceId, buyerName, buyerEmail, paymentMethod, details || '', tip || 0);
  const id = result.lastID;
  return db.get('SELECT * FROM orders WHERE id = ?', id);
}

async function markOrderPaid(id){
  const db = module.exports._db;
  await db.run('UPDATE orders SET status = ? WHERE id = ?', 'paid', id);
}

module.exports = { initDb, getAllServices, getServiceById, createOrder, markOrderPaid };
