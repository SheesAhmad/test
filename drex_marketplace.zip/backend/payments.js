// Payments helper (Coinbase Commerce placeholder)
const fetch = require('node-fetch');
const COINBASE_KEY = process.env.COINBASE_API_KEY || null;

async function createCryptoPayment(order){
  // This is a placeholder to demonstrate how to create a charge using Coinbase Commerce API.
  // In production, use official SDK and secure webhook verification.
  if (!COINBASE_KEY) return { message: 'coinbase not configured - simulate payment' };
  // Example request - note: in your environment use the official docs and handle webhooks securely.
  const payload = {
    name: 'Order #' + order.id,
    description: 'Payment for service ' + order.service_id,
    local_price: { amount: String(order.tip || 0), currency: 'USD' },
    pricing_type: 'fixed_price'
  };
  const res = await fetch('https://api.commerce.coinbase.com/charges', {
    method: 'POST',
    headers: { 'X-CC-Api-Key': COINBASE_KEY, 'X-CC-Version': '2018-03-22', 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  return data;
}

module.exports = { createCryptoPayment };
