// Discord webhook helper (simple)
const fetch = require('node-fetch');
const WEBHOOK = process.env.DISCORD_WEBHOOK_URL || '';

async function postNewOrder(order){
  if (!WEBHOOK) return;
  const body = {
    username: 'DrexBot',
    embeds: [{
      title: '🆕 New Order Received',
      description: `Order #${order.id} — service: ${order.service_id} — payment: ${order.payment_method}`,
      color: 65280,
      timestamp: new Date().toISOString()
    }]
  };
  await fetch(WEBHOOK, { method: 'POST', body: JSON.stringify(body), headers: {'Content-Type': 'application/json'} });
}

async function postPaymentConfirmed(order){
  if (!WEBHOOK) return;
  const body = { username: 'DrexBot', embeds:[{ title: '✅ Payment Confirmed', description: `Order #${order.id} marked paid`, color: 3066993, timestamp: new Date().toISOString() }] };
  await fetch(WEBHOOK, { method: 'POST', body: JSON.stringify(body), headers:{ 'Content-Type': 'application/json'} });
}

module.exports = { postNewOrder, postPaymentConfirmed };
