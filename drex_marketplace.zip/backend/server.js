// Drex Marketplace - Express backend scaffold (simple)
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const { initDb, getAllServices, getServiceById, createOrder, markOrderPaid } = require('./db');
const discord = require('./discord');
const payments = require('./payments');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const PORT = process.env.PORT || 3000;

// Static demo for the frontend folder if needed
app.use('/static', express.static(path.join(__dirname, '..', 'frontend')));

// API: list services (for homepage)
app.get('/api/services', async (req, res) => {
  const services = await getAllServices();
  res.json(services);
});

// API: service detail
app.get('/api/services/:id', async (req, res) => {
  const id = req.params.id;
  const s = await getServiceById(id);
  if (!s) return res.status(404).json({ error: 'Not found' });
  res.json(s);
});

// API: create order
app.post('/api/orders', async (req, res) => {
  const { serviceId, buyerName, buyerEmail, paymentMethod, details, tip } = req.body;
  try {
    const order = await createOrder({ serviceId, buyerName, buyerEmail, paymentMethod, details, tip });
    // send discord notification (webhook)
    discord.postNewOrder(order).catch(console.error);
    // If crypto payment selected, create payment session (stub)
    if (paymentMethod === 'crypto') {
      const session = await payments.createCryptoPayment(order);
      return res.json({ order, payment: session });
    }
    res.json({ order });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create order' });
  }
});

// API: confirm manual payment (admin/exchanger)
app.post('/api/orders/:id/confirm', async (req, res) => {
  const id = req.params.id;
  try {
    await markOrderPaid(id);
    const order = { id };
    await discord.postPaymentConfirmed(order).catch(console.error);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'confirm failed' });
  }
});

// Start server and init DB
initDb().then(()=>{
  app.listen(PORT, ()=> console.log('Server listening on', PORT));
}).catch(err => {
  console.error('DB init failed', err);
});
