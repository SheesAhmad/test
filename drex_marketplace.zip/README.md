# Drex Marketplace - Starter Template

## Overview
This is a complete starter template for a private freelance marketplace (Drex Marketplace).
It includes a premium-looking static frontend (HTML/CSS/JS) and an Express.js backend scaffold
with API routes, Discord/webhook placeholders, and payment integration hooks (Coinbase Commerce example).
The template is designed so your dev team can edit pricing, thumbnails, categories, and payment methods
later via the Admin panel or by modifying JSON files / database records.

## What is included
- `frontend/` — static premium frontend (homepage, category, service, cart, checkout, admin)
- `backend/` — Express.js server scaffold (API endpoints, Discord webhook helper, orders logic)
- `db/` — `schema.sql` (SQLite schema) and a small `seed` script
- `.env.example` — environment variables to set (Discord webhook, COINBASE keys)
- `package.json` — Node dependencies for backend (express, sqlite3, cors, body-parser, node-fetch)
- `LICENSE` — MIT

## How to run (local)
1. Install Node.js (v18+ recommended) and npm.
2. In the `backend/` folder run:
   ```bash
   npm install
   ```
3. Create `.env` in `backend/` based on `.env.example` and fill values.
4. Initialize the database (SQLite):
   ```bash
   sqlite3 db/drex.sqlite < db/schema.sql
   node backend/seed.js
   ```
5. Start the backend:
   ```bash
   node backend/server.js
   ```
6. Open `frontend/index.html` in your browser for the static demo UI (or serve it via any static file host).

## Notes & Next steps
- Payment integrations: crypto auto-confirm (Coinbase Commerce) hooks are placed in `backend/payments.js`.
- Discord: webhook helper in `backend/discord.js` posts order and payment events to Discord channels.
- Admin panel: `frontend/admin.html` contains editable fields that call backend APIs to update content.
- This is a starter template — connect to a proper DB (Postgres/Mongo) and production-grade hosting later.

## Contact
Built for: Drex — customize freely.
