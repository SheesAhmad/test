Use the backend/seed.js script to populate demo services (requires Node and sqlite3).
Steps:
1. npm install (in backend/)
2. sqlite3 db/drex.sqlite < db/schema.sql
3. node backend/seed.js
