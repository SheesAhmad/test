-- SQLite schema for Drex marketplace starter
CREATE TABLE services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT,
  category TEXT,
  price REAL,
  delivery_days INTEGER,
  image TEXT,
  description TEXT,
  featured INTEGER DEFAULT 0
);
CREATE TABLE orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  service_id INTEGER,
  buyer_name TEXT,
  buyer_email TEXT,
  payment_method TEXT,
  tip REAL DEFAULT 0,
  details TEXT,
  status TEXT DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
